﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyWallet.Web.ViewModels
{
    public class CurrencyTypeViewModel
    {
    }
}
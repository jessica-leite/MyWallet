﻿namespace MyWallet.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateTable_Context_AddColumn_IsMainContext : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Context", "IsMainContext", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Context", "IsMainContext");
        }
    }
}
